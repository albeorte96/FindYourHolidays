function borrarNombre(nombre){
	alert(nombre);
}